package com.bignerdranch.android.geoquiz;

import android.app.Activity;
import android.content.Intent;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;


public class QuizActivity extends AppCompatActivity implements NameDialog.ExampleDialogListener {

    private Button mTrueButton;
    private Button mFalseButton;
    private ImageButton mNextButton;
    private ImageButton mPrevButton;
    private Button mResetButton;
    private Button mCheatButton;
    private Button mResultButton;
    private TextView mQuestionTextView;
    private TextView mCheatTokensTextView;
    private TextView mNameTextView;

    private Question[] mQuestionBank = new Question[]{
            new Question(R.string.question_australia,true),
            new Question(R.string.question_oceans,true),
            new Question(R.string.question_mideast,false),
            new Question(R.string.question_americas,true),
            new Question(R.string.question_asia,true)
    };

    private int mCurrentIndex = 0;
    private int mScore =0;
    private boolean[] mIsCheater = new boolean[mQuestionBank.length];
    private boolean[] mIsAnswered = new boolean[mQuestionBank.length];
    private int mCheatTokens=3;
    private int mResetClicked = 0;
    private double mStartTime;
    private double mEndTime;
    private double mTimeTaken;
    private boolean mNameTaken;
    private boolean mResultShown = false;
    private String mName;

    private static final String TAG = "QuizActivity";
    private static final String KEY_INDEX ="index";
    private static final String KEY_GRADE = "grade";
    private static final String KEY_CHEATER ="cheater";
    private static final String KEY_ANSWERED ="answered";
    private static final String KEY_TOKENS = "tokens";
    private static final String KEY_NAME="name";
    private static final String KEY_RMB_NAME ="entered name";
    private static final String KEY_RESET_CLICKED="reset once";
    private static final String KEY_RESULT_SHOWN="result button shown";
    private static final String KEY_START_TIME="start time";
    private static final int REQUEST_CODE_CHEAT = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG,"onCreate(Bundle) called");
        setContentView(R.layout.activity_quiz);

        if(savedInstanceState !=null){
            mCurrentIndex = savedInstanceState.getInt(KEY_INDEX,0);
            mScore = savedInstanceState.getInt(KEY_GRADE,0);
            mIsCheater = savedInstanceState.getBooleanArray(KEY_CHEATER);
            mIsAnswered = savedInstanceState.getBooleanArray(KEY_ANSWERED);
            mCheatTokens = savedInstanceState.getInt(KEY_TOKENS,3);
            mNameTaken = savedInstanceState.getBoolean(KEY_RMB_NAME,false);
            mName=savedInstanceState.getString(KEY_NAME,"Anonymous");
            mResetClicked=savedInstanceState.getInt(KEY_RESET_CLICKED,0);
            mResultShown =savedInstanceState.getBoolean(KEY_RESULT_SHOWN,false);
            mStartTime=savedInstanceState.getDouble(KEY_START_TIME,0);
            }

        ifkeyedin();


        //timeTaken("start");
        mQuestionTextView = findViewById(R.id.question_text_view);
        mQuestionTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCurrentIndex = (mCurrentIndex+1)% mQuestionBank.length;
                updateQuestion(mCurrentIndex);
            }
        });

        mCheatTokensTextView =findViewById(R.id.cheat_tokens_text_view);
        mCheatTokensTextView.setText("Remaining Cheat Tokens: "+mCheatTokens);

        mNameTextView = findViewById(R.id.name_view);
        mNameTextView.setText("Name: "+mName);

        mTrueButton =  findViewById(R.id.true_button);
        mTrueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(true);
            }
        });
        mFalseButton = findViewById(R.id.false_button);
        mFalseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(false);
            }
        });

        mNextButton = findViewById(R.id.next_button);
        mNextButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                mCurrentIndex = (mCurrentIndex+1)% mQuestionBank.length;
                updateQuestion(mCurrentIndex);
            }

        });

        mPrevButton = findViewById(R.id.prev_button);
        mPrevButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCurrentIndex = (mCurrentIndex-1)% mQuestionBank.length;
                updateQuestion(mCurrentIndex);
            }
        });

        mResetButton =findViewById(R.id.reset_button);
        if(mResultShown){
            preReset();
        }else{
            mResetButton.setVisibility(View.GONE);
        }

        mResetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mResetClicked+=1;
                if(mResetClicked==1){
                    Toast.makeText(QuizActivity.this,"Are you sure to reset the answers? You only have a chance to do it so",Toast.LENGTH_SHORT).show();
                    Toast.makeText(QuizActivity.this, "Press Reset again to reset", Toast.LENGTH_SHORT).show();
                }
                else{
                    reset();
                }
            }
        });

        mCheatButton =findViewById(R.id.cheat_button);
        mCheatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean answerIsTrue = mQuestionBank[mCurrentIndex].isAnswerTrue();
                Intent intent = CheatActivity.newIntent(QuizActivity.this,answerIsTrue);
                startActivityForResult(intent,REQUEST_CODE_CHEAT);
            }
        });

        mResultButton= findViewById(R.id.result_summary_button);
        if (mResultShown){
            preReset();
        }else{
            mResultButton.setVisibility(View.GONE);
        }


        mResultButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String finalGrade=""+showGrade()+"";
                String cheatAttempts=""+(3-mCheatTokens)+"";
                String totalQuestions =""+mQuestionBank.length+"";
                String totalTimeTaken = ""+(Math.floor(mTimeTaken /1000))+"s";
                Intent intent= ResultSummary.newIntent(QuizActivity.this,mName,finalGrade,cheatAttempts,totalQuestions,totalTimeTaken,showGrade());
                startActivity(intent);

            }
        });
        updateQuestion(mCurrentIndex);

    }

    @Override
    protected void onActivityResult(int requestCode,int resultCode,Intent data){
        if(resultCode!= Activity.RESULT_OK){
            return;
        }
        if(requestCode==REQUEST_CODE_CHEAT){
            if(data==null){
                return;
            }
            mIsCheater[mCurrentIndex] = CheatActivity.wasAnswerShown(data);
            mCheatTokens-=1;
            mCheatTokensTextView.setText("Remaining Cheat Tokens: "+mCheatTokens);
            if(mCheatTokens==0){
                mCheatButton.setEnabled(false);
            }
        }

    }

    //To check if user has entered a name
    private void ifkeyedin(){
        if(mNameTaken ==false){
            openDialog();
        }
    }

    //Open the name dialog when the app opens
    private void openDialog(){
        NameDialog nameDialog = new NameDialog();
        nameDialog.setCancelable(false);
        nameDialog.show(getSupportFragmentManager(),"name dialog");
        mNameTaken =true;

    }

    //Apply user entered name on textView
    @Override
    public void applyTexts(String name) {
        mName=name;
        mNameTextView.setText("Name: "+name);
        timeTaken("start");
    }

    //Count the time user took to finish the quiz
    private void timeTaken(String a){
        if(a.equals("start")){
            mStartTime=SystemClock.elapsedRealtime();
        }else if(a.equals("end")){
            mEndTime =SystemClock.elapsedRealtime();
        }
        mTimeTaken = mEndTime -mStartTime;
    }


    //check if user has answered the question
    private void ifAnswered(boolean answered){
        if (answered) {
            mTrueButton.setVisibility(View.GONE);
            mFalseButton.setVisibility(View.GONE);
            mCheatButton.setEnabled(false);
        } else {
            mTrueButton.setVisibility(View.VISIBLE);
            mFalseButton.setVisibility(View.VISIBLE);
            mCheatButton.setEnabled(true);
        }
    }

    //Show grade after user had answered all the questions
    private int showGrade(){
        int finalGrade = (int)(((double) mScore /mQuestionBank.length)*100);
        CharSequence stringGrade = "Grade: "+finalGrade +"%";
        Toast.makeText(this, stringGrade, Toast.LENGTH_LONG).show();
        return finalGrade;
    }

    //update Questions when user click on the previous/next button or reset button
    private void updateQuestion(int index){
        if(index<0||index>4){
            mCurrentIndex=0;
        }
        ifAnswered(mIsAnswered[mCurrentIndex]);
        int question = mQuestionBank[mCurrentIndex].getTextResId();
        mQuestionTextView.setText(question);

    }

    //reset all questions answer, lead user back to the first question, enable all buttons
    public void reset(){
        for(int i=0;i<mIsAnswered.length;i++){
            mIsAnswered[i]=false;
        }
        for(int i =0;i<mIsCheater.length;i++){
            mIsCheater[i]=false;
        }
        mCurrentIndex=0;
        mScore =0;
        mCheatTokens=3;
        mCheatTokensTextView.setText("Remaining Cheat Tokens: "+mCheatTokens);
        mCheatButton.setEnabled(true);
        mResetButton.setVisibility(View.GONE);
        mResultButton.setVisibility(View.GONE);
        mResultShown =true;
        updateQuestion(mCurrentIndex);
    }

    //check if user has answered all the questions , show toast when there's questions left
    private void preReset(){
        int answered=0;
        for(int i =0;i<mIsAnswered.length;i++){
            if(mIsAnswered[i]){
                answered+=1;
            }
        }
        if((answered==5)&& mResetClicked<2){
            showGrade();
            timeTaken("end");
            mResultShown=true;
            mResetButton=findViewById(R.id.reset_button);
            mResetButton.setVisibility(View.VISIBLE);
            mResultButton=findViewById(R.id.result_summary_button);
            mResultButton.setVisibility(View.VISIBLE);

        }
        else if((answered==5)&& mResetClicked>1){
            showGrade();
            timeTaken("end");
            mResultShown =true;
            mResetButton=findViewById(R.id.reset_button);
            mResetButton.setEnabled(false);
            mResultButton=findViewById(R.id.result_summary_button);
            mResultButton.setVisibility(View.VISIBLE);

        }
        else if(((mCurrentIndex+1)==mQuestionBank.length)&&(answered!=5)){
            Toast.makeText(this, "There are quesntions left", Toast.LENGTH_LONG).show();

        }
    }

    //check answer for the questions
    private void checkAnswer(boolean userPressedTrue){
        boolean answerIsTrue = mQuestionBank[mCurrentIndex].isAnswerTrue();
        mIsAnswered[mCurrentIndex]=true;
        ifAnswered(mIsAnswered[mCurrentIndex]);
        int messageResId ;
            if(mIsCheater[mCurrentIndex]){
                messageResId=R.string.judgement_toast;
            }
            else{
                if (userPressedTrue == answerIsTrue) {
                    mScore += 1;
                    messageResId = R.string.correct_toast;

                } else {
                    messageResId = R.string.incorrect_toast;
                }
            }
        Toast.makeText(this,messageResId,Toast.LENGTH_SHORT).show();
        preReset();

    }

    @Override
    public void onStart(){
        super.onStart();
        Log.d(TAG,"onStart() called");
    }

    @Override
    public void onResume(){
        super.onResume();
        Log.d(TAG,"onResume() called");
    }

    @Override
    public void onPause(){
        super.onPause();
        Log.d(TAG,"onPause() called");
    }
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        Log.i(TAG,"onSaveInstanceState");
        savedInstanceState.putInt(KEY_INDEX,mCurrentIndex);
        savedInstanceState.putInt(KEY_GRADE, mScore);
        savedInstanceState.putInt(KEY_TOKENS,mCheatTokens);
        savedInstanceState.putBooleanArray(KEY_CHEATER,mIsCheater);
        savedInstanceState.putBooleanArray(KEY_ANSWERED,mIsAnswered);
        savedInstanceState.putString(KEY_NAME,mName);
        savedInstanceState.putBoolean(KEY_RMB_NAME, mNameTaken);
        savedInstanceState.putInt(KEY_RESET_CLICKED,mResetClicked);
        savedInstanceState.putBoolean(KEY_RESULT_SHOWN, mResultShown);
        savedInstanceState.putDouble(KEY_START_TIME,mStartTime);
    }
    @Override
    public void onStop(){
        super.onStop();
        Log.d(TAG,"onStop() called");
    }
    @Override
    public void onDestroy(){
        super.onDestroy();
        Log.d(TAG,"onDestroy() called");
    }
}
