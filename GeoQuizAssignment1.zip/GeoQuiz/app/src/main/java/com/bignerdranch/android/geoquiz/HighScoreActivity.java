package com.bignerdranch.android.geoquiz;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HighScoreActivity extends AppCompatActivity {

    private TextView mHighScoreTextView;
    private TextView mYourScoreTextView;
    private Button mTryAgainButton;

    private int mHighScore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_high_score);

        mHighScoreTextView=findViewById(R.id.high_score);
        mYourScoreTextView=findViewById(R.id.your_score);


        int mYourScore = getIntent().getIntExtra("SCORE",0);
        mYourScoreTextView.setText("Your Score was: "+mYourScore);

        SharedPreferences settings = getSharedPreferences("QUIZ_DATA",Context.MODE_PRIVATE);
        mHighScore=settings.getInt("HIGH_SCORE",0);

        if(mYourScore>mHighScore){
            mHighScoreTextView.setText("High Score: "+mYourScore);

            SharedPreferences.Editor editor=settings.edit();
            editor.putInt("HIGH_SCORE",mYourScore);
            editor.commit();
        }else{
            mHighScoreTextView.setText("High Score: "+mHighScore);
        }

        mTryAgainButton=findViewById(R.id.try_again_button);
        mTryAgainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //move to next page, QuizActivity
                Intent intent = new Intent(HighScoreActivity.this,QuizActivity.class);
                startActivity(intent);
            }
        });

    }

}
