package com.bignerdranch.android.geoquiz;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ResultSummary extends AppCompatActivity {


    private TextView mCheatAttemptsTextView;
    private TextView mTotalQuestionTextView;
    private TextView mFinalScoreTextView;
    private TextView mTimeTakenTextView;
    private TextView mNameTextView;
    private Button mHighScore;

    private String mFinalScore;
    private String mTotalQuestions;
    private String mTotalCheatAttempts;
    private String mTimeTaken;
    private String mName;

    private static final String EXTRA_TOTAL_QUESTION_ANSWERED="com.bignerdranch.android.geoquiz.total_question_answered";
    private static final String EXTRA_FINAL_SCORE="com.bignerdranch.android.geoquiz.final_score";
    private static final String EXTRA_TOTAL_CHEAT_ATTEMPTS="com.bignerdranch.android.geoquiz.total_cheat_attempts";
    private static final String EXTRA_TIME_TAKEN="com.bignerdranch.android.geoquiz.time_taken";
    private static final String EXTRA_NAME ="com.bignerdranch.android.geoquiz.name";
    private static final String mforhighscore = "need help";

   // private static final int REQUEST_CODE_START_SCREEN = 0;
    public static Intent newIntent(Context packageContext,String name,String finalScore,String totalCheats,String totalQuestions,String timeTaken,int forhighscore){
        Intent intent= new Intent(packageContext,ResultSummary.class);
        intent.putExtra(EXTRA_NAME,name);
        intent.putExtra(EXTRA_FINAL_SCORE,finalScore);
        intent.putExtra(EXTRA_TOTAL_CHEAT_ATTEMPTS,totalCheats);
        intent.putExtra(EXTRA_TOTAL_QUESTION_ANSWERED,totalQuestions);
        intent.putExtra(EXTRA_TIME_TAKEN,timeTaken);
        intent.putExtra(mforhighscore,forhighscore);
        return intent;
    }



    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_summary);

        mCheatAttemptsTextView=(TextView)findViewById(R.id.cheat_attempts);
        mTotalQuestionTextView=(TextView)findViewById(R.id.total_questions);
        mFinalScoreTextView=(TextView)findViewById(R.id.final_score);
        mTimeTakenTextView=(TextView)findViewById(R.id.time_taken);
        mNameTextView=(TextView)findViewById(R.id.name_view_rs);


        mFinalScore=getIntent().getStringExtra(EXTRA_FINAL_SCORE);
        mTotalQuestions=getIntent().getStringExtra(EXTRA_TOTAL_QUESTION_ANSWERED);
        mTotalCheatAttempts=getIntent().getStringExtra(EXTRA_TOTAL_CHEAT_ATTEMPTS);
        mTimeTaken=getIntent().getStringExtra(EXTRA_TIME_TAKEN);
        mName=getIntent().getStringExtra(EXTRA_NAME);


        mCheatAttemptsTextView.setText(mTotalCheatAttempts);
        mTotalQuestionTextView.setText(mTotalQuestions);
        mFinalScoreTextView.setText(mFinalScore);
        mTimeTakenTextView.setText(mTimeTaken);
        mNameTextView.setText(mName);


        mHighScore =findViewById(R.id.high_score);
        mHighScore.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                //move to next page, which is QuizActivity
                    Intent intent = new Intent(getApplicationContext(),HighScoreActivity.class);
                    intent.putExtra("SCORE",getIntent().getIntExtra(mforhighscore,0));
                    startActivity(intent);
                }

        });

    }


}
